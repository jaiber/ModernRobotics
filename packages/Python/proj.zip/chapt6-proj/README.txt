iterates.csv		- Output of various parameters during each iteration
log.txt			- Raw output of the program execution
screencast.mp4		- Screenrecording of UR5 robot running iterates.csv in CoppeliaSim
Screenshot.png		- Screenshot of URL in interactive mode

./code/chapter6-proj.py	- Code that contains the modified IKinBody
